from Preprocessor import Preprocessor

def main():
    pp = Preprocessor()
    tdpath = 'dataset/test/test-data-1'
    pp.process_test_data(tdpath)



main()
